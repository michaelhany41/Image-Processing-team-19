import cv2
import serial
import time
from ultralytics import YOLO

# 🔌 SERIAL SETUP
def init_serial():
    try:
        ser = serial.Serial('/dev/ttyACM0', 115200, timeout=0)
        time.sleep(2)
        ser.reset_input_buffer()
        print("✅ Arduino connected")
        return ser
    except Exception as e:
        print("❌ Serial error:", e)
        return None

ser = init_serial()

# 🧠 LOAD YOLO MODEL
# Use yolov8n.pt (nano) for faster performance on edge devices
print("Loading YOLO model...")
model = YOLO('yolov8n.pt') 
print("✅ Model loaded")

# 🎥 CAMERA
cap = cv2.VideoCapture(2)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)

last_send_time = 0
SEND_INTERVAL = 0.1
last_zone = None
frame_counter = 0

# Allowed class IDs to track: 32 (sports ball), 47 (apple), 49 (orange)
# Add more IDs to this list if it detects your ball as something else!
TARGET_CLASSES = [32, 47, 49] 

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # Process every frame for maximum responsiveness
    # (Removed the frame-skipping logic to track fast movements better)

    original = frame.copy()
    output = frame.copy()

    # -------------------------
    # 🧠 ML INFERENCE (YOLO)
    # -------------------------
    # Run YOLOv8 inference (lower conf threshold to see if it detects it weakly)
    results = model(frame, conf=0.15, verbose=False)
    
    cx, cy = None, None
    best_conf = 0

    # Parse results
    for r in results:
        boxes = r.boxes
        for box in boxes:
            cls = int(box.cls[0])
            conf = float(box.conf[0])
            
            # Get Bounding box coordinates
            x1_box, y1_box, x2_box, y2_box = box.xyxy[0].cpu().numpy().astype(int)
            label = f"{model.names[cls]} {conf:.2f}"
            
            # Draw ALL detected objects faintly so you can see what YOLO sees
            cv2.rectangle(output, (x1_box, y1_box), (x2_box, y2_box), (200, 200, 200), 1)
            cv2.putText(output, label, (x1_box, y1_box - 5), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.4, (200, 200, 200), 1)
            
            # If we're filtering by specific classes, skip others for target tracking
            if TARGET_CLASSES is not None and cls not in TARGET_CLASSES:
                continue
                
            # Keep the target detection with the highest confidence
            if conf > best_conf:
                best_conf = conf
                
                # Calculate centroid
                cx = (x1_box + x2_box) // 2
                cy = (y1_box + y2_box) // 2
                
                # Draw target bounding box and centroid strongly in green
                cv2.rectangle(output, (x1_box, y1_box), (x2_box, y2_box), (0, 255, 0), 2)
                cv2.circle(output, (cx, cy), 5, (0, 0, 255), -1)
                
                # Draw target label and confidence
                cv2.putText(output, f"TARGET: {label}", (x1_box, y1_box - 20), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

    # -------------------------
    # 🎯 GRID + ZONE
    # -------------------------
    w, h = 320, 240
    cell_w = w // 3
    cell_h = h // 3

    # Draw grid lines
    for i in range(1, 3):
        cv2.line(output, (i*cell_w, 0), (i*cell_w, h), (255, 255, 255), 1)
        cv2.line(output, (0, i*cell_h), (w, i*cell_h), (255, 255, 255), 1)

    zone = None

    if cx is not None:
        col = cx // cell_w
        row = cy // cell_h
        
        # Restrict column and row to 0, 1, or 2 (in case centroid is slightly out of bounds)
        col = max(0, min(col, 2))
        row = max(0, min(row, 2))
        
        zone = int(row * 3 + col + 1)

        x1 = col * cell_w
        y1 = row * cell_h
        x2 = x1 + cell_w
        y2 = y1 + cell_h

        # Highlight the current zone
        cv2.rectangle(output, (x1, y1), (x2, y2), (0, 255, 255), 2)
        cv2.putText(output, f"Zone: {zone}", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
    else:
        cv2.putText(output, "No Target", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)

    # -------------------------
    # ⏱️ SERIAL SEND
    # -------------------------
    current_time = time.time()

    if current_time - last_send_time > SEND_INTERVAL:
        try:
            if ser and ser.is_open:
                if zone is None:
                    if last_zone is not None:
                        ser.write(b'0\n')
                        last_zone = None
                else:
                    if zone != last_zone:
                        print(f"📡 Sending zone: {zone}")
                        ser.write(f"{zone}\n".encode())
                        last_zone = zone

                last_send_time = current_time
        except:
            ser = init_serial()

    # -------------------------
    # 🖥️ DISPLAY ALL STEPS
    # -------------------------
    cv2.imshow("1 - Original", original)
    cv2.imshow("2 - YOLO Detection + Grid", output)

    if cv2.waitKey(1) == 27:
        break

    time.sleep(0.02)

cap.release()
if ser:
    ser.close()
cv2.destroyAllWindows()

print("✅ Program ended")
