import cv2
import numpy as np
import serial
import time

# 🔌 SERIAL SETUP
def init_serial():
    try:
        ser = serial.Serial('/dev/ttyACM0', 115200, timeout=0)
        time.sleep(2)
        ser.reset_input_buffer()
        print("✅ Arduino connected")
        return ser
    except Exception as e:
        print("❌ Serial error:", e)
        return None

ser = init_serial()

# 🎥 CAMERA
cap = cv2.VideoCapture(2)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)

last_send_time = 0
SEND_INTERVAL = 0.1
last_zone = None

frame_counter = 0

while True:
    ret, frame = cap.read()
    if not ret:
        break

    frame_counter += 1
    if frame_counter % 2 != 0:
        continue

    # -------------------------
    # 🎯 STEP 1: ORIGINAL
    # -------------------------
    original = frame.copy()

    # -------------------------
    # 🎯 STEP 2: HSV
    # -------------------------
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    # convert HSV to displayable BGR (for visualization)
    hsv_display = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)

    # -------------------------
    # 🎯 STEP 3: MASK
    # -------------------------
    lower_white = np.array([0, 0, 200])
    upper_white = np.array([180, 30, 255])

    mask = cv2.inRange(hsv, lower_white, upper_white)

    # -------------------------
    # 🎯 STEP 4: CLEAN MASK
    # -------------------------
    kernel = np.ones((7,7), np.uint8)
    clean_mask = cv2.medianBlur(mask, 7)
    clean_mask = cv2.morphologyEx(clean_mask, cv2.MORPH_OPEN, kernel)

    # -------------------------
    # 🎯 STEP 5: DETECTION
    # -------------------------
    output = frame.copy()

    contours,_ = cv2.findContours(clean_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    cx, cy = None, None

    if len(contours) > 0:
        c = max(contours, key=cv2.contourArea)

        if cv2.contourArea(c) > 500:
            x,y,w,h = cv2.boundingRect(c)
            cx = x + w//2
            cy = y + h//2

            cv2.rectangle(output,(x,y),(x+w,y+h),(0,255,0),2)
            cv2.circle(output,(cx,cy),5,(0,0,255),-1)

    # -------------------------
    # 🎯 GRID + ZONE
    # -------------------------
    w, h = 320, 240
    cell_w = w // 3
    cell_h = h // 3

    for i in range(1,3):
        cv2.line(output, (i*cell_w,0), (i*cell_w,h), (255,255,255),1)
        cv2.line(output, (0,i*cell_h), (w,i*cell_h), (255,255,255),1)

    zone = None

    if cx is not None:
        col = cx // cell_w
        row = cy // cell_h
        zone = int(row * 3 + col + 1)

        x1 = col * cell_w
        y1 = row * cell_h
        x2 = x1 + cell_w
        y2 = y1 + cell_h

        cv2.rectangle(output, (x1,y1), (x2,y2), (0,255,255), 2)

        cv2.putText(output, f"Zone: {zone}", (10,30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,255), 2)
    else:
        cv2.putText(output, "No Ball", (10,30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,0,255), 2)

    # -------------------------
    # ⏱️ SERIAL SEND
    # -------------------------
    current_time = time.time()

    if current_time - last_send_time > SEND_INTERVAL:
        try:
            if ser and ser.is_open:
                if zone is None:
                    if last_zone is not None:
                        ser.write(b'0\n')
                        last_zone = None
                else:
                    if zone != last_zone:
                        print(f"📡 Sending zone: {zone}")
                        ser.write(f"{zone}\n".encode())
                        last_zone = zone

                last_send_time = current_time
        except:
            ser = init_serial()

    # -------------------------
    # 🖥️ DISPLAY ALL STEPS
    # -------------------------
    cv2.imshow("1 - Original", original)
    cv2.imshow("2 - HSV", hsv_display)
    cv2.imshow("3 - Mask", mask)
    cv2.imshow("4 - Clean Mask", clean_mask)
    cv2.imshow("5 - Detection + Grid", output)

    if cv2.waitKey(1) == 27:
        break

    time.sleep(0.02)

cap.release()
if ser:
    ser.close()
cv2.destroyAllWindows()

print("✅ Program ended")